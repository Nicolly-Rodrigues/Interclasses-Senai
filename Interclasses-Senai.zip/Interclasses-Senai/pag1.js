function selecionarModalidade(modalidade) {
  alert(`Você selecionou: ${modalidade}`);
}